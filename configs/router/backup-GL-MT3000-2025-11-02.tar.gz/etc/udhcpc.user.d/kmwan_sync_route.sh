#!/bin/sh
. /lib/functions/kmwan.sh

sync_route_netcell
